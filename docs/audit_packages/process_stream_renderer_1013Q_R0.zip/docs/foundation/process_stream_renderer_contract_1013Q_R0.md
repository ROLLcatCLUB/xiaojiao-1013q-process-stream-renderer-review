# 1013Q_R0 Process Stream Renderer Contract

Stage: `1013Q_R0_PROCESS_STREAM_RENDERER_CONTRACT`

Final target for this stage: define a preview-only Process Stream Renderer contract for the Shiwei prep room and courseware-making area.

## Background

This line absorbs product-form inspiration from public education AI tools, but it does not copy, reverse engineer, reproduce, scrape, or reuse any external product code, API paths, assets, UI visuals, wording, or business implementation.

The product lesson is narrow:

- A teacher should see how XiaoJiao understands a request before seeing a final draft.
- Evidence, textbook position, uploaded materials, and mismatch risk must be visible.
- When confidence is low or source matching is uncertain, generation must pause behind a teacher confirmation gate.
- The final result in this line is an editable draft entry, not a formal write.

## Scope

This contract belongs to the prep room / courseware-making direction. It is not a standalone courseware generation site.

This stage is separate from `1013P`:

- `1013P` handles new uploaded art reference materials and `art_reference_case`.
- `1013Q` handles process-stream presentation and renderer semantics.

## Product Definition

The Process Stream Renderer is not:

- a chat transcript
- a field form
- a final lesson-plan article
- a real model runtime
- a courseware publishing system

It is:

- a teacher-readable work-process surface
- a renderer for request understanding, task planning, source review, warning, confirmation, and draft-entry state
- a preview contract for future R36-derived prep-room preview integration

## Required Stream Shape

Every `process_stream` payload must include:

- `stream_id`
- `stream_title`
- `workspace_context`
- `user_request`
- `current_stage`
- `blocks`
- `teacher_confirmation_state`
- `final_output_ref`
- `review_state`

Every block must include:

- `block_id`
- `block_type`
- `display_title`
- `summary`
- `status`
- `confidence_level`
- `source_status`
- `teacher_confirmation_required`
- `teacher_action_required`
- `visible_priority`
- `collapse_default`
- `evidence_refs`
- `warnings`
- `actions`

## Rendering Principles

1. Main conclusion first, technical flags lower in the hierarchy.
2. Evidence blocks must show source status and confidence level.
3. Warning or low-confidence blocks must provide a teacher action.
4. Missing material or mismatch risk must create a teacher confirmation gate.
5. The visible persona name is XiaoJiao.
6. Final output is an editable draft entry.
7. No arbitrary HTML or JavaScript from fixture data may execute.
8. No provider, database, Feishu, student endpoint, export, publishing, or formal apply is allowed in this stage.

## Block Type Enum

- `user_request_block`
- `intent_understanding_block`
- `task_plan_block`
- `source_review_block`
- `textbook_alignment_block`
- `curriculum_alignment_block`
- `material_intake_block`
- `mismatch_warning_block`
- `teacher_confirmation_gate`
- `unit_design_stream_block`
- `lesson_design_stream_block`
- `art_demo_stream_block`
- `courseware_seed_stream_block`
- `final_output_block`

## Status Enum

- `pending`
- `running`
- `completed`
- `needs_confirmation`
- `warning`
- `blocked`
- `skipped`

## Source Status Enum

- `official_verified_candidate`
- `official_unverified_candidate`
- `teacher_uploaded_reference`
- `generated_inference`
- `missing`
- `mismatch_detected`
- `not_applicable`

## Confidence Enum

- `high`
- `medium`
- `low`
- `unknown`

## Teacher Action Enum

- `none`
- `confirm`
- `edit`
- `upload_material`
- `select_source`
- `correct_textbook_position`
- `ask_xiaojiao`
- `regenerate_from_this_step`
- `block_generation`

## Next Stage

If this contract passes, the next stage is:

`1013Q_R1_PROCESS_STREAM_RENDERER_PREP_ROOM_PREVIEW_POLISH`

R1 may copy from the R36 prep-room preview baseline, but R0 does not connect to R36.
