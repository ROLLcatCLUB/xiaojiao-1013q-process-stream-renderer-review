# 1013Q_R0 Process Stream Renderer Boundary

This stage is intentionally small.

## Allowed

- Create contract documents.
- Create fixture JSON files.
- Create a static renderer preview page.
- Create a validator.
- Create audit report, manifest, and ZIP package.
- Use local files only.

## Forbidden

- Real provider calls.
- Real model calls.
- Database writes.
- Feishu writes.
- Memory writes.
- Student endpoint connection.
- PPT export.
- Community publishing.
- Formal apply.
- R36 formal body chain modification.
- External site scraping.
- External product reverse engineering.
- Copying external code, API names, assets, UI visuals, or wording.
- Running arbitrary HTML or JavaScript from fixture data.

## Frontstage Naming

The teacher-visible persona for this line is:

`小教`

The legacy assistant name may appear only in internal governance or historical notes, never in new teacher-visible fixture or preview copy for this stage.

## Review Gate Rule

If any stream has `source_status` equal to `missing` or `mismatch_detected`, or `confidence_level` equal to `low`, it must include a `teacher_confirmation_gate` block before any editable draft entry.
