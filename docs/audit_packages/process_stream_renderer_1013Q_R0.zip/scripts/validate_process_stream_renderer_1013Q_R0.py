from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path


STAGE_ID = "1013Q_R0_PROCESS_STREAM_RENDERER_CONTRACT"
FINAL_STATUS = "PASS_PROCESS_STREAM_RENDERER_CONTRACT"
NEXT_STAGE = "1013Q_R1_PROCESS_STREAM_RENDERER_PREP_ROOM_PREVIEW_POLISH"

FIXTURE_PATHS = [
    Path("fixtures/process_stream/lesson_design_normal_1013Q_R0.json"),
    Path("fixtures/process_stream/material_missing_1013Q_R0.json"),
    Path("fixtures/process_stream/source_mismatch_warning_1013Q_R0.json"),
    Path("fixtures/process_stream/courseware_seed_preview_1013Q_R0.json"),
]

DOC_PATHS = [
    Path("docs/foundation/process_stream_renderer_contract_1013Q_R0.md"),
    Path("docs/foundation/process_stream_renderer_contract_1013Q_R0.json"),
    Path("docs/foundation/process_stream_block_schema_1013Q_R0.json"),
    Path("docs/foundation/process_stream_renderer_boundary_1013Q_R0.md"),
]

PREVIEW_PATH = Path("frontend/workbench/process_stream_renderer_preview_1013Q_R0.html")
REPORT_PATH = Path("docs/audit/process_stream_renderer_1013Q_R0_report.md")
MANIFEST_PATH = Path("docs/audit_packages/process_stream_renderer_1013Q_R0_manifest.json")
ZIP_PATH = Path("docs/audit_packages/process_stream_renderer_1013Q_R0.zip")

REQUIRED_PAYLOAD_FIELDS = {
    "stream_id",
    "stream_title",
    "workspace_context",
    "user_request",
    "current_stage",
    "blocks",
    "teacher_confirmation_state",
    "final_output_ref",
    "review_state",
}

REQUIRED_BLOCK_FIELDS = {
    "block_id",
    "block_type",
    "display_title",
    "summary",
    "status",
    "confidence_level",
    "source_status",
    "teacher_confirmation_required",
    "teacher_action_required",
    "visible_priority",
    "collapse_default",
    "evidence_refs",
    "warnings",
    "actions",
}

ALLOWED_BLOCK_TYPES = {
    "user_request_block",
    "intent_understanding_block",
    "task_plan_block",
    "source_review_block",
    "textbook_alignment_block",
    "curriculum_alignment_block",
    "material_intake_block",
    "mismatch_warning_block",
    "teacher_confirmation_gate",
    "unit_design_stream_block",
    "lesson_design_stream_block",
    "art_demo_stream_block",
    "courseware_seed_stream_block",
    "final_output_block",
}

ALLOWED_STATUSES = {"pending", "running", "completed", "needs_confirmation", "warning", "blocked", "skipped"}
ALLOWED_SOURCE_STATUSES = {
    "official_verified_candidate",
    "official_unverified_candidate",
    "teacher_uploaded_reference",
    "generated_inference",
    "missing",
    "mismatch_detected",
    "not_applicable",
}
ALLOWED_CONFIDENCE = {"high", "medium", "low", "unknown"}
ALLOWED_ACTIONS = {
    "none",
    "confirm",
    "edit",
    "upload_material",
    "select_source",
    "correct_textbook_position",
    "ask_xiaojiao",
    "regenerate_from_this_step",
    "block_generation",
}

FORBIDDEN_REGEXES = [
    re.compile(r"feixianglaoshi\.com", re.I),
    re.compile(r"https?://(?:www\.)?feixiang", re.I),
    re.compile(r"from\s+backend\.xiaobei_ai\.providers", re.I),
    re.compile(r"import\s+providers", re.I),
    re.compile(r"OPENAI_API_KEY|ANTHROPIC_API_KEY|MINIMAX_API_KEY", re.I),
    re.compile(r"provider_model_call_allowed[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"formal_apply_allowed[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"database_write_allowed[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"feishu_write_allowed[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"ppt_export_enabled[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"provider_called[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"model_called[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"database_written[\"']?\s*[:=]\s*true", re.I),
    re.compile(r"formal_apply_performed[\"']?\s*[:=]\s*true", re.I),
]

FORBIDDEN_CAPABILITY_TERMS = [
    "scrape_feixiang",
    "reverse_engineer_feixiang",
    "external_feixiang_api",
]


def fail(message: str) -> None:
    raise AssertionError(message)


def load_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as exc:
        fail(f"JSON parse failed: {path}: {exc}")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def ensure_exists(root: Path, rel_paths: list[Path]) -> None:
    for rel in rel_paths:
        if not (root / rel).exists():
            fail(f"Missing required file: {rel}")


def validate_fixture(path: Path, data: dict) -> None:
    missing = REQUIRED_PAYLOAD_FIELDS - set(data)
    if missing:
        fail(f"{path} missing payload fields: {sorted(missing)}")

    context = data["workspace_context"]
    if context.get("visible_agent_name") != "小教":
        fail(f"{path} visible_agent_name must be 小教")
    if context.get("preview_only") is not True or context.get("fixture_only") is not True:
        fail(f"{path} must be preview_only=true and fixture_only=true")

    final_ref = data["final_output_ref"]
    if final_ref.get("formal_output_created") is not False:
        fail(f"{path} final_output_ref.formal_output_created must be false")

    blocks = data["blocks"]
    if not isinstance(blocks, list) or not blocks:
        fail(f"{path} blocks must be a non-empty list")

    block_types = {block.get("block_type") for block in blocks}
    if "user_request_block" not in block_types or "intent_understanding_block" not in block_types:
        fail(f"{path} must include user_request_block and intent_understanding_block")

    for block in blocks:
        block_missing = REQUIRED_BLOCK_FIELDS - set(block)
        if block_missing:
            fail(f"{path} block {block.get('block_id')} missing fields: {sorted(block_missing)}")
        if block["block_type"] not in ALLOWED_BLOCK_TYPES:
            fail(f"{path} block {block['block_id']} invalid block_type: {block['block_type']}")
        if block["status"] not in ALLOWED_STATUSES:
            fail(f"{path} block {block['block_id']} invalid status: {block['status']}")
        if block["source_status"] not in ALLOWED_SOURCE_STATUSES:
            fail(f"{path} block {block['block_id']} invalid source_status: {block['source_status']}")
        if block["confidence_level"] not in ALLOWED_CONFIDENCE:
            fail(f"{path} block {block['block_id']} invalid confidence_level: {block['confidence_level']}")
        if block["teacher_action_required"] not in ALLOWED_ACTIONS:
            fail(
                f"{path} block {block['block_id']} invalid teacher_action_required: "
                f"{block['teacher_action_required']}"
            )
        if not isinstance(block["evidence_refs"], list):
            fail(f"{path} block {block['block_id']} evidence_refs must be a list")
        if block["source_status"] in {"missing", "mismatch_detected"} and block["teacher_action_required"] == "none":
            fail(f"{path} block {block['block_id']} has missing/mismatch source with no teacher action")
        if block["confidence_level"] in {"low", "unknown"} and block["status"] in {"warning", "blocked", "needs_confirmation"}:
            if block["teacher_action_required"] == "none":
                fail(f"{path} block {block['block_id']} has warning/blocked low confidence with no teacher action")
        if block["block_type"] == "mismatch_warning_block" and block["teacher_action_required"] == "none":
            fail(f"{path} mismatch_warning_block must require a teacher action")

    stream_id = data["stream_id"]
    if stream_id == "source_mismatch_warning_1013Q_R0":
        if "mismatch_warning_block" not in block_types or "teacher_confirmation_gate" not in block_types:
            fail(f"{path} mismatch fixture must include warning and confirmation gate")
        if final_ref.get("editable_draft_entry") is not False:
            fail(f"{path} mismatch fixture must not expose editable final draft")
    if stream_id == "material_missing_1013Q_R0":
        if "teacher_confirmation_gate" not in block_types:
            fail(f"{path} missing-material fixture must include teacher confirmation gate")
        if final_ref.get("editable_draft_entry") is not False:
            fail(f"{path} missing-material fixture must not expose editable final draft")
    if stream_id == "courseware_seed_preview_1013Q_R0":
        if "courseware_seed_stream_block" not in block_types:
            fail(f"{path} courseware seed fixture must show generation process")
        if final_ref.get("kind") != "courseware_seed_editable_draft_entry":
            fail(f"{path} courseware seed fixture final kind mismatch")


def scan_forbidden(root: Path, rel_paths: list[Path]) -> None:
    for rel in rel_paths:
        text = read_text(root / rel)
        for pattern in FORBIDDEN_REGEXES:
            if pattern.search(text):
                fail(f"Forbidden pattern {pattern.pattern!r} found in {rel}")
        lowered = text.lower()
        for term in FORBIDDEN_CAPABILITY_TERMS:
            if term in lowered:
                fail(f"Forbidden capability term {term!r} found in {rel}")


def validate_preview(root: Path) -> None:
    text = read_text(root / PREVIEW_PATH)
    if "小备" in text:
        fail(f"{PREVIEW_PATH} must not contain teacher-visible 小备 copy")
    for rel in FIXTURE_PATHS:
        if str(rel).replace("\\", "/") not in text:
            fail(f"{PREVIEW_PATH} does not reference fixture {rel}")
    if "http://" in text or "https://" in text:
        fail(f"{PREVIEW_PATH} must not call external URLs")


def validate_contract(root: Path) -> None:
    contract = load_json(root / Path("docs/foundation/process_stream_renderer_contract_1013Q_R0.json"))
    if contract.get("stage_id") != STAGE_ID:
        fail("contract json stage_id mismatch")
    if contract.get("final_status_if_pass") != FINAL_STATUS:
        fail("contract json final_status_if_pass mismatch")
    if contract.get("next_stage") != NEXT_STAGE:
        fail("contract json next_stage mismatch")
    if contract.get("boundaries", {}).get("visible_agent_name") != "小教":
        fail("contract json boundary visible_agent_name must be 小教")
    for key, expected in {
        "provider_called": False,
        "model_called": False,
        "database_written": False,
        "feishu_written": False,
        "ppt_export_enabled": False,
        "formal_apply_performed": False,
        "r36_chain_modified": False,
        "external_site_scrape": False,
    }.items():
        if contract.get("boundaries", {}).get(key) is not expected:
            fail(f"contract boundary mismatch: {key}")

    schema = load_json(root / Path("docs/foundation/process_stream_block_schema_1013Q_R0.json"))
    if "blocks" not in schema.get("required", []):
        fail("schema must require blocks")
    block_required = set(schema.get("$defs", {}).get("block", {}).get("required", []))
    missing = REQUIRED_BLOCK_FIELDS - block_required
    if missing:
        fail(f"schema block required list missing: {sorted(missing)}")


def validate_manifest_and_zip(root: Path) -> None:
    manifest = load_json(root / MANIFEST_PATH)
    if manifest.get("stage_id") != STAGE_ID:
        fail("manifest stage_id mismatch")
    if manifest.get("final_status") != FINAL_STATUS:
        fail("manifest final_status mismatch")
    if manifest.get("next_stage") != NEXT_STAGE:
        fail("manifest next_stage mismatch")

    entries = manifest.get("zip_entries")
    if not isinstance(entries, list) or not entries:
        fail("manifest zip_entries must be a non-empty list")
    if str(ZIP_PATH).replace("\\", "/") in entries:
        fail("zip must not contain itself")
    for entry in entries:
        if not (root / entry).exists():
            fail(f"manifest entry missing on disk: {entry}")

    zip_path = root / ZIP_PATH
    if not zip_path.exists():
        fail(f"missing zip package: {ZIP_PATH}")
    with zipfile.ZipFile(zip_path, "r") as package:
        actual = sorted(package.namelist())
    expected = sorted(entries)
    if actual != expected:
        fail(f"zip entries do not match manifest: expected={expected}, actual={actual}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate 1013Q_R0 process stream renderer contract.")
    parser.add_argument("--root", default=None, help="Repository root. Defaults to the parent of scripts/.")
    args = parser.parse_args()

    root = Path(args.root).resolve() if args.root else Path(__file__).resolve().parents[1]

    try:
        ensure_exists(root, DOC_PATHS + FIXTURE_PATHS + [PREVIEW_PATH, REPORT_PATH, MANIFEST_PATH, ZIP_PATH])
        validate_contract(root)
        for rel in FIXTURE_PATHS:
            validate_fixture(rel, load_json(root / rel))
        scan_forbidden(root, DOC_PATHS + FIXTURE_PATHS + [PREVIEW_PATH, REPORT_PATH, MANIFEST_PATH])
        validate_preview(root)
        validate_manifest_and_zip(root)
    except AssertionError as exc:
        print(f"VALIDATION_FAIL: {STAGE_ID}")
        print(f"ERROR={exc}")
        return 1

    print(f"VALIDATION_PASS: {STAGE_ID}")
    print(f"FINAL_STATUS={FINAL_STATUS}")
    print(f"NEXT_STAGE={NEXT_STAGE}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
